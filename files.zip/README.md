# 🎣 Daily Wilmington Fishing Report — SMS via Twilio

Sends a daily SMS with tide, weather, wind, and bait suggestions for Wilmington, NC.

---

## Quick Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set your environment variables
```bash
cp .env.example .env
# Edit .env with your values
export $(cat .env | xargs)
```

### 3. Get your Twilio credentials
1. Sign up free at https://www.twilio.com
2. From the Console dashboard, copy your **Account SID** and **Auth Token**
3. Get a free phone number (Twilio gives you one on signup)
4. Add to `.env`:
   - `TWILIO_ACCOUNT_SID` = your Account SID
   - `TWILIO_AUTH_TOKEN`  = your Auth Token
   - `TWILIO_FROM`        = your Twilio phone number (e.g. +19105551234)
   - `TWILIO_TO`          = your personal cell number

### 4. Test it manually
```bash
python daily_fishing_sms.py
```
You should receive a text within seconds.

---

## Schedule it daily (choose one)

### Option A — Mac/Linux cron (runs at 6 AM daily)
```bash
crontab -e
```
Add this line (update the path to match where you saved the files):
```
0 6 * * * cd /path/to/fishing_report && export $(cat .env | xargs) && python daily_fishing_sms.py >> /tmp/fishing.log 2>&1
```

### Option B — Railway.app (free cloud hosting, always on)
1. Push this folder to a GitHub repo
2. Go to https://railway.app → New Project → Deploy from GitHub
3. Add environment variables in Railway's dashboard (Settings → Variables)
4. Add a **Cron Job** service: schedule `0 6 * * *`, command `python daily_fishing_sms.py`

### Option C — Render.com (free tier)
1. Create a new **Cron Job** service at https://render.com
2. Connect your GitHub repo
3. Set build command: `pip install -r requirements.txt`
4. Set run command: `python daily_fishing_sms.py`
5. Schedule: `0 6 * * *`
6. Add env vars in Render's dashboard

---

## What's in each text

```
🎣 Wilmington Fishing Report — Fri, Mar 15

⛅ Weather: 68°F high / 52°F low
💨 Wind: 10 mph SE
🌧️ Rain: 0.0" expected
🟢 Great day to fish!

🌊 Tides (NOAA):
  High: 7:12 AM (4.8 ft)
  Low:  1:34 PM (0.3 ft)
  High: 7:51 PM (4.6 ft)

⏰ Best window: 5:12 AM – 7:12 AM

🪱 Suggested bait:
  • Live shrimp (under a popping cork near grass edges)
  • Gulp! Swimming mullet (chartreuse or white)
  • Topwater (Spook Jr. or Skitter Walk) during low-light windows

Good luck out there! 🐟
```

---

## Customization

- **Change station**: Edit `NOAA_STATION` in the script. Find your station at https://tidesandcurrents.noaa.gov
- **Change send time**: Adjust the cron schedule (`0 6 * * *` = 6:00 AM daily)
- **Add more recipients**: Call `send_sms()` multiple times with different `to` numbers
- **Change units**: Set `temperature_unit` to `celsius` and `windspeed_unit` to `kmh` in `get_weather()`
